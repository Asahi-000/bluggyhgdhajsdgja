<?php
// Database connection
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'blog';

try {
    $pdo = new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME . ';charset=utf8', $DATABASE_USER, $DATABASE_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $exception) {
    exit('Failed to connect to database: ' . $exception->getMessage());
}

// Fetch the page_id from the GET request
$page_id = isset($_GET['page_id']) ? $_GET['page_id'] : null;
if (!$page_id) {
    exit('Page ID is required');
}

// Fetch the comments with user details
$stmt = $pdo->prepare('SELECT comments.*, users.username FROM comments 
                       LEFT JOIN users ON comments.user_id = users.ID 
                       WHERE page_id = ? ORDER BY submit_date DESC');
$stmt->execute([$page_id]);
$comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Function to format the time difference
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);
    $string = ['y' => 'year','m' => 'month','w' => 'week','d' => 'day','h' => 'hour','i' => 'minute','s' => 'second'];
    
    foreach ($string as $k => &$v) {
        if (isset($diff->$k) && $diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }
    
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

// Display the comments in HTML format
$html = '';
foreach ($comments as $comment) {
    $username = htmlspecialchars($comment['username'], ENT_QUOTES);
    $content = nl2br(htmlspecialchars($comment['content'], ENT_QUOTES));
    $submit_date = time_elapsed_string($comment['submit_date']);
    
    $html .= '
    <div class="comment">
        <div>
            <h3 class="name">' . $username . '</h3>
            <span class="date">' . $submit_date . '</span>
        </div>
        <p class="content">' . $content . '</p>
    </div>';
}

// Output the comments HTML
echo $html;
?>
