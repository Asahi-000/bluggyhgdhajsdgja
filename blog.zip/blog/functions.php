<?php
function show_comments($pdo, $post_id, $parent_comment_id = 0) {
    // Fetch comments based on post_id and parent_comment_id
    $stmt = $pdo->prepare('SELECT comments.*, users.username AS user_username 
                           FROM comments 
                           LEFT JOIN users ON comments.user_id = users.ID 
                           WHERE post_id = ? AND parent_comment_id = ? 
                           ORDER BY submit_date DESC');
    $stmt->execute([$post_id, $parent_comment_id]);
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $html = '';
    foreach ($comments as $comment) {
        // Get the username of the comment author or set to 'Anonymous' if none exists
        $name = !empty($comment['user_username']) ? htmlspecialchars($comment['user_username'], ENT_QUOTES) : 'Anonymous';

        
        // Show the main comment and its details
        $html .= '
        <div class="comment" data-comment-id="' . $comment['ID'] . '">
            <div>
                <h3 class="name">' . $name . '</h3>
                <span class="date">' . time_elapsed_string($comment['submit_date']) . '</span>
            </div>
            <p class="content">' . nl2br(htmlspecialchars($comment['content'], ENT_QUOTES)) . '</p>
            
            <!-- Reply button -->
            <a href="#" class="reply_comment_btn" data-comment-id="' . $comment['ID'] . '">Reply</a>

            <!-- Replies to this comment (recursively call show_comments) -->
            <div class="replies">
                ' . show_comments($pdo, $post_id, $comment['ID']) . '
            </div>

            <!-- The reply form is hidden initially and shown when "Reply" is clicked -->
            <div class="write_comment" style="display:none;" data-comment-id="' . $comment['ID'] . '">
                <form method="POST" class="reply_form">
                    <input type="hidden" name="parent_comment_id" value="' . $comment['ID'] . '">
                    <textarea name="content" placeholder="Write your reply here..." required></textarea>
                    <button type="submit">Submit Reply</button>
                </form>
            </div>
        </div>';
    }
    return $html;
}

// Function to convert time to a human-readable format
function time_elapsed_string($datetime, $full = false) {
    // Set timezone to Asia/Manila
    $timezone = new DateTimeZone('Asia/Manila');

    // Get current time in the Manila timezone
    $now = new DateTime('now', $timezone);

    // Convert input datetime to Manila timezone
    $ago = new DateTime($datetime, $timezone);

    // Get the difference between current time and the input datetime
    $diff = $now->diff($ago);

    // Time string format
    $string = array(
        'y' => 'year',
        'm' => 'month',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second'
    );

    // Format the difference into a readable string
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    // Limit the result to the first unit of time if $full is false
    if (!$full) $string = array_slice($string, 0, 1);

    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

?>
